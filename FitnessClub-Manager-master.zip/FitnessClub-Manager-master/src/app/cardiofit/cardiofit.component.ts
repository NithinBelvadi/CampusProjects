import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cardiofit',
  templateUrl: './cardiofit.component.html',
  styleUrls: ['./cardiofit.component.css']
})
export class CardiofitComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
