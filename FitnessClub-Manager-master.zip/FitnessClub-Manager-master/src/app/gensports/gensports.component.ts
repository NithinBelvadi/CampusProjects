import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gensports',
  templateUrl: './gensports.component.html',
  styleUrls: ['./gensports.component.css']
})
export class GensportsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
