import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-childrenfac',
  templateUrl: './childrenfac.component.html',
  styleUrls: ['./childrenfac.component.css']
})
export class ChildrenfacComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
