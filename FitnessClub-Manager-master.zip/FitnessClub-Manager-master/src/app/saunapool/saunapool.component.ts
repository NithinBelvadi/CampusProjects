import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-saunapool',
  templateUrl: './saunapool.component.html',
  styleUrls: ['./saunapool.component.css']
})
export class SaunapoolComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
