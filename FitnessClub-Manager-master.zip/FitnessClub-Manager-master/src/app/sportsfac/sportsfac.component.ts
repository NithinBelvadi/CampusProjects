import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sportsfac',
  templateUrl: './sportsfac.component.html',
  styleUrls: ['./sportsfac.component.css']
})
export class SportsfacComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
