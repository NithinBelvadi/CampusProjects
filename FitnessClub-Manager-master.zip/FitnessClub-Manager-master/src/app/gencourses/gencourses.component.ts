import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gencourses',
  templateUrl: './gencourses.component.html',
  styleUrls: ['./gencourses.component.css']
})
export class GencoursesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
