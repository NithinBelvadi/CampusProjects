import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-genevents',
  templateUrl: './genevents.component.html',
  styleUrls: ['./genevents.component.css']
})
export class GeneventsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
